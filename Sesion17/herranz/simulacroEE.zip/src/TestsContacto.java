import quepasa.Contacto;

public class TestsContacto {
  public static void main(String[] args) {
    Contacto c = new Contacto();
    assert c != null;
  }
}
