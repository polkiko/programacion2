package acotados;

public class ListaAcotada<E> implements Lista<E> {
}
