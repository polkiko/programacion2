package quepasa;

public class Contacto {
}
