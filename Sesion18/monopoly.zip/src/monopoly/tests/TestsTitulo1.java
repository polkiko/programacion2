package monopoly.tests;

import monopoly.dominio.*;

public class TestsTitulo1 {

  public static void main(String[] args) {
    Titulo lavapies = new Titulo(Color.VIOLETA,
                                 "Plaza Lavapies",
                                 50,
                                 50,
                                 null);

    assert lavapies.color() == Color.VIOLETA;
    assert "Plaza Lavapies".equals(lavapies.nombre());
    assert lavapies.precioCasa() == 50;
    assert lavapies.precioHotel() == 50;
    assert lavapies.casas() == 0;
    assert !lavapies.hotel();
    lavapies.construirCasa();
    assert lavapies.casas() == 1;
    assert !lavapies.hotel();
    lavapies.construirHotel();
    assert lavapies.casas() == 1;
    assert !lavapies.hotel();
    lavapies.construirCasa();
    lavapies.construirHotel();
    assert lavapies.casas() == 2;
    assert !lavapies.hotel();
    lavapies.construirCasa();
    lavapies.construirCasa();
    assert lavapies.casas() == 4;
    assert !lavapies.hotel();
    lavapies.construirHotel();
    assert lavapies.casas() == 0;
    assert lavapies.hotel();
  }
}
