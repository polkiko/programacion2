package monopoly.tests;

import monopoly.dominio.*;

public class TestsTitulo2 {

  public static void main(String[] args) {
    int[] alquiler = {4, 20, 60, 180, 320, 450};
    Titulo lavapies = new Titulo(Color.VIOLETA,
                                 "Plaza Lavapies",
                                 50,
                                 50,
                                 alquiler);

    assert lavapies.alquiler() == alquiler[0];
    lavapies.marcarGrupoCompleto();
    assert lavapies.alquiler() == 2 * alquiler[0];
    for (int i = 1; i <= 4; i++) {
      lavapies.construirHotel();
      lavapies.construirCasa();
      assert lavapies.alquiler() == alquiler[i];
    }
    lavapies.construirCasa();
    assert lavapies.alquiler() == alquiler[4];
    lavapies.construirHotel();
    assert lavapies.alquiler() == alquiler[5];
  }
}
