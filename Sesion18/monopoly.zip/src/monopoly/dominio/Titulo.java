package monopoly.dominio;

public class Titulo {
}
