package monopoly.dominio;

public enum Color {
  VIOLETA, AZUL, ROSA, NARANJA, ROJO, AMARILLO, VERDE, MORADO
}
